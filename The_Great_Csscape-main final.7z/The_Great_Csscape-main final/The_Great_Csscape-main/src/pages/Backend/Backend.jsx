

const BackendOutputPage = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Enter the pincode:</h1>
    </div>);
    {
      "Message":"Number of Post office(s) found: 21",
      "Status":"Success",
      "PostOffice":[
         {
            "Name":"Baroda House",
            "Description":"",
            "BranchType":"Sub Post Office",
            "DeliveryStatus":"Non-Delivery",
            "Circle":"New Delhi",
            "District":"Central Delhi",
            "Division":"New Delhi Central",
            "Region":"Delhi",
            "State":"Delhi",
            "Country":"India"
         }
      ]
   }
};

export default BackendOutputPage;
