import React from "react";
import "../css/Errorfix.css";
import logo from "../assets/profile.png";
import PropTypes from 'prop-types';

const ProfilePage = ({ email = "example@example.com", phone = "123-456-7890", linkedin = "https://linkedin.com/in/example", github = "https://github.com/example" }) => {
  const [likes, setLikes] = React.useState(0);

  const handleLike = () => {
    setLikes((prevLikes) => prevLikes + 1);
  };

  return (
    <div className="profile-page">
      <header className="profile-header">
        <div className="profile-header-content">
          <img src={logo} alt="Profile" className="profile-image" />
          <div className="profile-header-text">
            <h1 className="profile-name">John Doe</h1>
            <h2 className="profile-title">Senior Software Engineer</h2>
            <p className="profile-summary">
              Experienced in designing and developing scalable, high-performance web applications. Skilled in full-stack development, team leadership, and agile methodologies.
            </p>
          </div>
        </div>
      </header>
      <main className="profile-content">
        <section className="profile-section">
          <h3 className="section-title">Skills</h3>
          <ul className="skills-list">
            <li>React, Angular, and Vue.js</li>
            <li>Node.js, Express, and Python/Django</li>
            <li>RESTful and GraphQL API development</li>
            <li>Database design: MySQL, MongoDB, and PostgreSQL</li>
            <li>Cloud: AWS, Azure, and Google Cloud Platform</li>
            <li>CI/CD pipelines and DevOps tools</li>
            <li>Unit and Integration Testing: Jest, Mocha, and Cypress</li>
          </ul>
        </section>
        {/* Add other sections similarly */}
        <section className="profile-section">
          <h3 className="section-title">Contact</h3>
          <p>
            <strong>Email:</strong> {email}
          </p>
          <p>
            <strong>Phone:</strong> {phone}
          </p>
          <p>
            <strong>LinkedIn:</strong>{" "}
            <a href={linkedin} target="_blank" rel="noopener noreferrer">
              {linkedin}
            </a>
          </p>
          <p>
            <strong>GitHub:</strong>{" "}
            <a href={github} target="_blank" rel="noopener noreferrer">
              {github}
            </a>
          </p>
        </section>
        <section className="profile-section">
          <button className="like-button" onClick={handleLike}>
            Like ({likes})
          </button>
        </section>
      </main>
    </div>
  );
};
ProfilePage.propTypes = {
  email: PropTypes.string.isRequired, // Define prop types with .isRequired
  phone: PropTypes.string.isRequired,
  linkedin: PropTypes.string.isRequired,
  github: PropTypes.string.isRequired,
};


export default ProfilePage;